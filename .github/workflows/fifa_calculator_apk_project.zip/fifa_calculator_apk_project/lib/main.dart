import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const FifaCalculatorApp());
}

class FifaCalculatorApp extends StatelessWidget {
  const FifaCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fifa',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090D16),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          secondary: Color(0xFFFBBF24),
          surface: Color(0xFF0F172A),
          error: Color(0xFFF43F5E),
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: CalculatorHomeScreen(),
      ),
    );
  }
}

class HistoryEntry {
  final String expression;
  final String result;
  final DateTime timestamp;

  HistoryEntry({
    required this.expression,
    required this.result,
    required this.timestamp,
  });
}

class CalculatorHomeScreen extends StatefulWidget {
  const CalculatorHomeScreen({super.key});

  @override
  State<CalculatorHomeScreen> createState() => _CalculatorHomeScreenState();
}

class _CalculatorHomeScreenState extends State<CalculatorHomeScreen> {
  String _currentInput = '0';
  String _expression = '';
  bool _justEvaluated = false;
  bool _isDegree = true;
  bool _showScientific = false;
  double _memoryValue = 0.0;
  final List<HistoryEntry> _history = [];

  void _triggerHaptic() {
    HapticFeedback.lightImpact();
  }

  String _formatNumber(double val) {
    if (val.isNaN || val.isInfinite) return 'خطأ رياضي';
    final double rounded = (val * 1e10).roundToDouble() / 1e10;
    if (rounded == rounded.truncateToDouble()) {
      return rounded.toInt().toString();
    }
    return rounded
        .toStringAsFixed(10)
        .replaceFirst(RegExp(r'0+$'), '')
        .replaceFirst(RegExp(r'\.$'), '');
  }

  String _formatDisplayExpression(String expr) {
    if (expr.isEmpty) return '0';
    return expr
        .replaceAll('*', ' × ')
        .replaceAll('/', ' ÷ ')
        .replaceAll('+', ' + ')
        .replaceAll('-', ' − ');
  }

  void _onInput(String value) {
    _triggerHaptic();
    const operators = ['+', '-', '*', '/', '^'];

    setState(() {
      if (operators.contains(value)) {
        if (_justEvaluated) {
          _expression = '$_currentInput$value';
          _justEvaluated = false;
          _currentInput = '0';
        } else {
          _expression += '$_currentInput$value';
          _currentInput = '0';
        }
        return;
      }

      if (value == '(' || value == ')') {
        if (_justEvaluated) {
          _expression = '';
          _currentInput = '0';
          _justEvaluated = false;
        }
        if (value == '(' && _currentInput != '0') {
          _expression += '$_currentInput*(';
          _currentInput = '0';
        } else if (value == '(') {
          _expression += '(';
        } else {
          _expression += '$_currentInput)';
          _currentInput = '0';
        }
        return;
      }

      if (_justEvaluated) {
        _currentInput = value == '.' ? '0.' : value;
        _expression = '';
        _justEvaluated = false;
        return;
      }

      if (value == '.') {
        if (!_currentInput.contains('.')) {
          _currentInput += '.';
        }
      } else if (value == '%') {
        final numVal = double.tryParse(_currentInput);
        if (numVal != null) {
          _currentInput = _formatNumber(numVal / 100.0);
        }
      } else {
        _currentInput = _currentInput == '0' ? value : '$_currentInput$value';
      }
    });
  }

  void _onScientific(String op) {
    _triggerHaptic();
    final double x = double.tryParse(_currentInput) ?? 0.0;
    double res = x;
    String label = '';

    final double angleRad = _isDegree ? (x * math.pi / 180.0) : x;

    setState(() {
      switch (op) {
        case 'sin':
          res = math.sin(angleRad);
          label = 'sin($x)';
          break;
        case 'cos':
          res = math.cos(angleRad);
          label = 'cos($x)';
          break;
        case 'tan':
          res = math.tan(angleRad);
          label = 'tan($x)';
          break;
        case 'sqrt':
          if (x < 0) {
            _currentInput = 'خطأ رياضي';
            _justEvaluated = true;
            return;
          }
          res = math.sqrt(x);
          label = '√($x)';
          break;
        case 'sq':
          res = x * x;
          label = '($x)²';
          break;
        case 'log':
          if (x <= 0) {
            _currentInput = 'خطأ رياضي';
            _justEvaluated = true;
            return;
          }
          res = math.log(x) / math.ln10;
          label = 'log($x)';
          break;
        case 'ln':
          if (x <= 0) {
            _currentInput = 'خطأ رياضي';
            _justEvaluated = true;
            return;
          }
          res = math.log(x);
          label = 'ln($x)';
          break;
        case 'inv':
          if (x == 0) {
            _currentInput = 'لا يمكن القسمة على 0';
            _justEvaluated = true;
            return;
          }
          res = 1.0 / x;
          label = '1/($x)';
          break;
        case 'pi':
          res = math.pi;
          label = 'π';
          break;
      }

      final String formatted = _formatNumber(res);
      if (label.isNotEmpty && formatted != 'خطأ رياضي') {
        _history.insert(
          0,
          HistoryEntry(
            expression: label,
            result: formatted,
            timestamp: DateTime.now(),
          ),
        );
      }
      _currentInput = formatted;
      _justEvaluated = true;
    });
  }

  void _onMemory(String action) {
    _triggerHaptic();
    final double current = double.tryParse(_currentInput) ?? 0.0;
    setState(() {
      switch (action) {
        case 'MC':
          _memoryValue = 0.0;
          break;
        case 'MR':
          _currentInput = _formatNumber(_memoryValue);
          _justEvaluated = false;
          break;
        case 'M+':
          _memoryValue += current;
          break;
        case 'M-':
          _memoryValue -= current;
          break;
      }
    });
  }

  void _onClear() {
    _triggerHaptic();
    setState(() {
      _currentInput = '0';
      _expression = '';
      _justEvaluated = false;
    });
  }

  void _onBackspace() {
    _triggerHaptic();
    setState(() {
      if (_justEvaluated) {
        _expression = '';
        _justEvaluated = false;
      }
      if (_currentInput.length > 1 && _currentInput != 'خطأ رياضي') {
        _currentInput = _currentInput.substring(0, _currentInput.length - 1);
      } else {
        _currentInput = '0';
      }
    });
  }

  void _onToggleSign() {
    _triggerHaptic();
    setState(() {
      if (_currentInput == '0' || _currentInput == 'خطأ رياضي') return;
      if (_currentInput.startsWith('-')) {
        _currentInput = _currentInput.substring(1);
      } else {
        _currentInput = '-$_currentInput';
      }
    });
  }

  void _onEquals() {
    _triggerHaptic();
    final String candidate =
        _justEvaluated ? _currentInput : '$_expression$_currentInput';
    final double? evaluated = ExpressionEvaluator.evaluate(candidate);

    setState(() {
      if (evaluated == null || evaluated.isNaN || evaluated.isInfinite) {
        _currentInput = 'خطأ رياضي';
        _justEvaluated = true;
        return;
      }
      final String formatted = _formatNumber(evaluated);
      _history.insert(
        0,
        HistoryEntry(
          expression: _formatDisplayExpression(candidate),
          result: formatted,
          timestamp: DateTime.now(),
        ),
      );
      _expression = '$candidate =';
      _currentInput = formatted;
      _justEvaluated = true;
    });
  }

  String _getLivePreview() {
    if (_expression.isEmpty || _justEvaluated) return '';
    final String candidate = '$_expression$_currentInput';
    final double? val = ExpressionEvaluator.evaluate(candidate);
    if (val == null || val.isNaN || val.isInfinite) return '';
    final String formatted = _formatNumber(val);
    if (formatted == _currentInput) return '';
    return '= $formatted';
  }

  void _showHistorySheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F172A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'سجل العمليات الحسابية',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () {
                        setState(() => _history.clear());
                        Navigator.pop(ctx);
                      },
                      icon: const Icon(Icons.delete_outline,
                          color: Color(0xFFF43F5E), size: 18),
                      label: const Text(
                        'مسح السجل',
                        style: TextStyle(color: Color(0xFFF43F5E)),
                      ),
                    ),
                  ],
                ),
                const Divider(color: Color(0xFF1E293B)),
                Expanded(
                  child: _history.isEmpty
                      ? const Center(
                          child: Text(
                            'لا توجد عمليات مسجلة بعد',
                            style: TextStyle(color: Colors.white54),
                          ),
                        )
                      : ListView.separated(
                          itemCount: _history.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (_, index) {
                            final item = _history[index];
                            return InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () {
                                setState(() {
                                  _currentInput = item.result;
                                  _expression = '';
                                  _justEvaluated = true;
                                });
                                Navigator.pop(ctx);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 12,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E293B),
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                child: Directionality(
                                  textDirection: TextDirection.ltr,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Flexible(
                                        child: Text(
                                          '${item.expression} =',
                                          style: const TextStyle(
                                            color: Colors.white60,
                                            fontSize: 14,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Text(
                                        item.result,
                                        style: const TextStyle(
                                          color: Color(0xFF10B981),
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final String preview = _getLivePreview();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F172A),
        elevation: 0,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF10B981), Color(0xFF059669)],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              alignment: Alignment.center,
              child: const Text(
                'F',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Fifa',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'حاسبة Flutter أصلية',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.white54,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'الوضع العلمي',
            onPressed: () {
              setState(() => _showScientific = !_showScientific);
            },
            icon: Icon(
              Icons.science_outlined,
              color:
                  _showScientific ? const Color(0xFF10B981) : Colors.white70,
            ),
          ),
          IconButton(
            tooltip: 'السجل',
            onPressed: _showHistorySheet,
            icon: Badge(
              isLabelVisible: _history.isNotEmpty,
              label: Text('${_history.length}'),
              backgroundColor: const Color(0xFF10B981),
              textColor: Colors.black,
              child: const Icon(Icons.history, color: Colors.white70),
            ),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(14.0),
          child: Column(
            children: [
              // Display Screen Card
              Expanded(
                flex: 3,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F172A),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF1E293B)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              InkWell(
                                onTap: () =>
                                    setState(() => _isDegree = !_isDegree),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF1E293B),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    _isDegree ? 'DEG' : 'RAD',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFFBBF24),
                                    ),
                                  ),
                                ),
                              ),
                              if (_memoryValue != 0) ...[
                                const SizedBox(width: 8),
                                Text(
                                  'M = ${_formatNumber(_memoryValue)}',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFFFBBF24),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            tooltip: 'نسخ النتيجة',
                            onPressed: () {
                              Clipboard.setData(
                                ClipboardData(text: _currentInput),
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('تم نسخ النتيجة'),
                                  duration: Duration(seconds: 1),
                                ),
                              );
                            },
                            icon: const Icon(
                              Icons.copy_rounded,
                              size: 18,
                              color: Colors.white54,
                            ),
                          ),
                        ],
                      ),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              reverse: true,
                              child: Text(
                                _expression.isEmpty
                                    ? '0'
                                    : _formatDisplayExpression(_expression),
                                style: const TextStyle(
                                  fontSize: 18,
                                  color: Colors.white54,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerRight,
                              child: Text(
                                _currentInput,
                                style: const TextStyle(
                                  fontSize: 44,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            if (preview.isNotEmpty)
                              Text(
                                preview,
                                style: const TextStyle(
                                  fontSize: 15,
                                  color: Color(0xFF10B981),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Memory Bar
              Directionality(
                textDirection: TextDirection.ltr,
                child: Row(
                  children: [
                    for (final mem in ['MC', 'MR', 'M+', 'M-'])
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white70,
                              side: const BorderSide(color: Color(0xFF1E293B)),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: () => _onMemory(mem),
                            child: Text(
                              mem,
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              // Optional Scientific Row
              if (_showScientific) ...[
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          _buildSciBtn('sin', () => _onScientific('sin')),
                          _buildSciBtn('cos', () => _onScientific('cos')),
                          _buildSciBtn('tan', () => _onScientific('tan')),
                          _buildSciBtn('log', () => _onScientific('log')),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          _buildSciBtn('√x', () => _onScientific('sqrt')),
                          _buildSciBtn('x²', () => _onScientific('sq')),
                          _buildSciBtn('xʸ', () => _onInput('^')),
                          _buildSciBtn('1/x', () => _onScientific('inv')),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          _buildSciBtn('(', () => _onInput('(')),
                          _buildSciBtn(')', () => _onInput(')')),
                          _buildSciBtn('π', () => _onScientific('pi')),
                          _buildSciBtn('ln', () => _onScientific('ln')),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],

              // Main Keypad Grid
              Expanded(
                flex: 6,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Column(
                    children: [
                      _buildKeyRow([
                        _CalcKey('AC',
                            bg: const Color(0xFF3F1D28),
                            fg: const Color(0xFFF43F5E),
                            onTap: _onClear),
                        _CalcKey('⌫',
                            bg: const Color(0xFF1E293B),
                            fg: Colors.white,
                            onTap: _onBackspace),
                        _CalcKey('%',
                            bg: const Color(0xFF1E293B),
                            fg: const Color(0xFF10B981),
                            onTap: () => _onInput('%')),
                        _CalcKey('÷',
                            bg: const Color(0xFF132F2B),
                            fg: const Color(0xFF10B981),
                            onTap: () => _onInput('/')),
                      ]),
                      _buildKeyRow([
                        _CalcKey('7', onTap: () => _onInput('7')),
                        _CalcKey('8', onTap: () => _onInput('8')),
                        _CalcKey('9', onTap: () => _onInput('9')),
                        _CalcKey('×',
                            bg: const Color(0xFF132F2B),
                            fg: const Color(0xFF10B981),
                            onTap: () => _onInput('*')),
                      ]),
                      _buildKeyRow([
                        _CalcKey('4', onTap: () => _onInput('4')),
                        _CalcKey('5', onTap: () => _onInput('5')),
                        _CalcKey('6', onTap: () => _onInput('6')),
                        _CalcKey('−',
                            bg: const Color(0xFF132F2B),
                            fg: const Color(0xFF10B981),
                            onTap: () => _onInput('-')),
                      ]),
                      _buildKeyRow([
                        _CalcKey('1', onTap: () => _onInput('1')),
                        _CalcKey('2', onTap: () => _onInput('2')),
                        _CalcKey('3', onTap: () => _onInput('3')),
                        _CalcKey('+',
                            bg: const Color(0xFF132F2B),
                            fg: const Color(0xFF10B981),
                            onTap: () => _onInput('+')),
                      ]),
                      _buildKeyRow([
                        _CalcKey('±', onTap: _onToggleSign),
                        _CalcKey('0', onTap: () => _onInput('0')),
                        _CalcKey('.', onTap: () => _onInput('.')),
                        _CalcKey('=',
                            bg: const Color(0xFF10B981),
                            fg: const Color(0xFF090D16),
                            onTap: _onEquals),
                      ]),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSciBtn(String label, VoidCallback onTap) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1E293B),
            foregroundColor: const Color(0xFF6EE7B7),
            padding: const EdgeInsets.symmetric(vertical: 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          onPressed: onTap,
          child: Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
          ),
        ),
      ),
    );
  }

  Widget _buildKeyRow(List<_CalcKey> keys) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: keys
              .map(
                (k) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: k.bg ?? const Color(0xFF0F172A),
                        foregroundColor: k.fg ?? Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                          side: const BorderSide(color: Color(0xFF1E293B)),
                        ),
                      ),
                      onPressed: k.onTap,
                      child: Text(
                        k.label,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}

class _CalcKey {
  final String label;
  final Color? bg;
  final Color? fg;
  final VoidCallback onTap;

  _CalcKey(this.label, {this.bg, this.fg, required this.onTap});
}

/// Pure Dart Mathematical Expression Parser (Shunting-Yard Algorithm)
class ExpressionEvaluator {
  static double? evaluate(String raw) {
    String expr = raw.trim().replaceAll(RegExp(r'[+\-*/^]+$'), '');
    if (expr.isEmpty) return null;

    final int openParens = '('.allMatches(expr).length;
    final int closeParens = ')'.allMatches(expr).length;
    if (openParens > closeParens) {
      expr += ')' * (openParens - closeParens);
    }

    try {
      final List<String> tokens = _tokenize(expr);
      final List<String> rpn = _toRPN(tokens);
      return _evalRPN(rpn);
    } catch (_) {
      return null;
    }
  }

  static List<String> _tokenize(String expr) {
    final List<String> tokens = [];
    String numberBuffer = '';

    for (int i = 0; i < expr.length; i++) {
      final String ch = expr[i];
      if ('0123456789.'.contains(ch)) {
        numberBuffer += ch;
      } else if (ch == '-' &&
          numberBuffer.isEmpty &&
          (tokens.isEmpty || '+-*/^('.contains(tokens.last))) {
        numberBuffer += ch;
      } else if ('+-*/^()'.contains(ch)) {
        if (numberBuffer.isNotEmpty) {
          tokens.add(numberBuffer);
          numberBuffer = '';
        }
        tokens.add(ch);
      }
    }
    if (numberBuffer.isNotEmpty) {
      tokens.add(numberBuffer);
    }
    return tokens;
  }

  static int _precedence(String op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    if (op == '^') return 3;
    return 0;
  }

  static List<String> _toRPN(List<String> tokens) {
    final List<String> output = [];
    final List<String> ops = [];

    for (final token in tokens) {
      if (double.tryParse(token) != null) {
        output.add(token);
      } else if (token == '(') {
        ops.add(token);
      } else if (token == ')') {
        while (ops.isNotEmpty && ops.last != '(') {
          output.add(ops.removeLast());
        }
        if (ops.isNotEmpty && ops.last == '(') {
          ops.removeLast();
        }
      } else {
        while (ops.isNotEmpty &&
            _precedence(ops.last) >= _precedence(token) &&
            token != '^') {
          output.add(ops.removeLast());
        }
        ops.add(token);
      }
    }
    while (ops.isNotEmpty) {
      output.add(ops.removeLast());
    }
    return output;
  }

  static double? _evalRPN(List<String> rpn) {
    final List<double> stack = [];
    for (final token in rpn) {
      final double? numVal = double.tryParse(token);
      if (numVal != null) {
        stack.add(numVal);
      } else {
        if (stack.length < 2) return null;
        final double b = stack.removeLast();
        final double a = stack.removeLast();
        switch (token) {
          case '+':
            stack.add(a + b);
            break;
          case '-':
            stack.add(a - b);
            break;
          case '*':
            stack.add(a * b);
            break;
          case '/':
            if (b == 0) return double.nan;
            stack.add(a / b);
            break;
          case '^':
            stack.add(math.pow(a, b).toDouble());
            break;
        }
      }
    }
    return stack.length == 1 ? stack.single : null;
  }
}