# Fifa Calculator — Android APK build

This repository contains the Flutter source and a GitHub Actions workflow that builds a release APK.

## Build the APK without installing Flutter locally
1. Create/sign in to a GitHub account.
2. Create a new repository and upload the contents of this folder (including the `.github` folder).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Press **Run workflow** (or push to `main`/`master` to trigger it automatically).
5. When the run finishes, open it and download the artifact named `fifa-calculator-apk`.
6. Extract the downloaded ZIP; it contains `app-release.apk`. Transfer it to your Android phone and install it. You may need to allow installation from that file manager.

The APK is not included yet; it is produced by the workflow after you run it on GitHub.
